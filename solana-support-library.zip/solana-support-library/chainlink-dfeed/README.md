# Solana Chainlink Dfeed

Dummy price feed for simulating Chainlink for testing on localhost